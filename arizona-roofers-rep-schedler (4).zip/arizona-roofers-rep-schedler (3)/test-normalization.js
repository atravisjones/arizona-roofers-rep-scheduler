// Quick test script to verify address normalization
// Run with: node test-normalization.js

const normalizeAddressForMatching = (address) => {
    if (!address) return null;

    let addr = address.toLowerCase().trim();

    // Cautiously remove state and zip from the very end of the string
    addr = addr.replace(/(,\s*(az|arizona))?\s+\d{5}(?:-\d{4})?$/, '');

    // Cautiously remove just the state from the end if it's there
    addr = addr.replace(/,\s*(az|arizona)$/, '');

    // Clean up any trailing comma left from the removals
    addr = addr.trim().replace(/,$/, '').trim();

    // Simplified: just remove ", gilbert" or similar
    addr = addr.replace(/,\s*\w+\s*$/, '').trim();

    // What remains should be the core street address.
    let streetPart = addr;

    // The address must start with a number.
    const streetNumberMatch = streetPart.match(/^(\d+)/);
    if (!streetNumberMatch) return null;

    // Expand abbreviations like St, Rd, N, W, etc. to their full words.
    streetPart = streetPart
        .replace(/\b(n\.?|north)\b/g, 'north')
        .replace(/\b(s\.?|south)\b/g, 'south')
        .replace(/\b(e\.?|east)\b/g, 'east')
        .replace(/\b(w\.?|west)\b/g, 'west')
        .replace(/\b(st\.?|street)\b/g, 'street')
        .replace(/\b(rd\.?|road)\b/g, 'road')
        .replace(/\b(dr\.?|drive)\b/g, 'drive')
        .replace(/\b(ave?\.?|avenue)\b/g, 'avenue')
        .replace(/\b(blvd\.?|boulevard)\b/g, 'boulevard')
        .replace(/\b(ln\.?|lane)\b/g, 'lane')
        .replace(/\b(ct\.?|court)\b/g, 'court')
        .replace(/\b(pl\.?|place)\b/g, 'place')
        .replace(/\b(trl\.?|trail)\b/g, 'trail')
        .replace(/\b(cir\.?|circle)\b/g, 'circle')
        .replace(/\b(wy\.?|way)\b/g, 'way');

    // Remove all non-alphanumeric characters (except spaces) and collapse whitespace.
    streetPart = streetPart.replace(/[^a-z0-9\s]/g, '');
    streetPart = streetPart.replace(/\s+/g, ' ').trim();

    return streetPart;
};

// Test cases
const address1 = "701 N Cooper Rd, Gilbert, AZ 85233";
const address2 = "701 North Cooper Road, Gilbert, AZ 85233";

const normalized1 = normalizeAddressForMatching(address1);
const normalized2 = normalizeAddressForMatching(address2);

console.log("Address 1:", address1);
console.log("Normalized 1:", normalized1);
console.log();
console.log("Address 2:", address2);
console.log("Normalized 2:", normalized2);
console.log();
console.log("Match:", normalized1 === normalized2 ? "✅ YES" : "❌ NO");
