/**
 * Week Schedule Parser
 * Parses a full week's schedule and splits it into individual days
 */

export interface DaySchedule {
  dayName: string; // e.g., "Sunday", "Monday"
  date: string; // e.g., "Dec 7, 2025"
  fullDate: string; // e.g., "Sunday, Dec 7, 2025"
  content: string; // The full text content for that day
}

/**
 * Parses a weekly schedule text and splits it into individual day schedules
 */
export function parseWeekSchedule(weekText: string): DaySchedule[] {
  const days: DaySchedule[] = [];

  // Day header pattern: e.g., "Sunday, Dec 7, 2025" or "Monday, Dec 8, 2025"
  const dayHeaderPattern = /^(Sunday|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday),\s+([A-Za-z]+\s+\d+,\s+\d{4})$/gim;

  const lines = weekText.split('\n');
  let currentDay: DaySchedule | null = null;
  let currentContent: string[] = [];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();

    // Check if this line is a day header
    const headerMatch = line.match(/^(Sunday|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday),\s+([A-Za-z]+\s+\d+,\s+\d{4})$/i);

    if (headerMatch) {
      // Save the previous day if it exists
      if (currentDay) {
        currentDay.content = currentContent.join('\n').trim();
        if (currentDay.content) {
          days.push(currentDay);
        }
      }

      // Start a new day
      const dayName = headerMatch[1];
      const date = headerMatch[2];
      currentDay = {
        dayName,
        date,
        fullDate: `${dayName}, ${date}`,
        content: ''
      };
      currentContent = [line]; // Include the header in the content
    } else if (currentDay) {
      // Add content to the current day
      currentContent.push(line);
    }
  }

  // Don't forget to save the last day
  if (currentDay) {
    currentDay.content = currentContent.join('\n').trim();
    if (currentDay.content) {
      days.push(currentDay);
    }
  }

  return days;
}

/**
 * Validates if the text appears to be a weekly schedule
 */
export function isWeekSchedule(text: string): boolean {
  const dayHeaderPattern = /(Sunday|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday),\s+[A-Za-z]+\s+\d+,\s+\d{4}/i;
  const matches = text.match(new RegExp(dayHeaderPattern, 'gi'));

  // If we find at least 2 day headers, it's likely a week schedule
  return matches !== null && matches.length >= 2;
}

/**
 * Gets a summary of the week schedule
 */
export function getWeekSummary(days: DaySchedule[]): string {
  if (days.length === 0) return 'No days found';

  const firstDay = days[0];
  const lastDay = days[days.length - 1];

  return `${firstDay.dayName} ${firstDay.date} - ${lastDay.dayName} ${lastDay.date} (${days.length} days)`;
}
