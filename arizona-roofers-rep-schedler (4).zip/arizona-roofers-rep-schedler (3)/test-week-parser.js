// Test script to verify week parsing works correctly
const sampleWeekData = `Sunday, Dec 7, 2025

7:30am-9am (1)
AVONDALE 2 years Tile 1S 2525sq. 85323 - 10763 W Hill Dr, Avondale, AZ 85323

10am-12pm (0)

1pm-3pm (0)

4pm-6pm (0)


Monday, Dec 8, 2025

7:30am-9am (1)
MARICOPA # (old roof) 19yrs Tile 1S 1564sq. 85138 - 40119 W Mary Dr, Maricopa, AZ 85138

10am-12pm (11)
STAR VALLEY # Shingle 1S 1798sq. 85541 - 161 West Chitwood Trail, Star Valley, Arizona, United States London Smith


Tuesday, Dec 9, 2025

7:30am-9am (9)
PHOENIX ### (Large/Older Home, Old Roof, Reroof Request) 24yrs Tile 1S 3421sq. 85042 - 915 E Valencia Dr, Phoenix, AZ 85042
MESA # (old roof/rental prep) 27yrs Tile 1S 1502sq. 85215 - 6061 E Rochelle St, Mesa, AZ 85215`;

// Parse the week schedule
function parseWeekSchedule(weekText) {
  const days = [];
  const dayHeaderPattern = /^(Sunday|Monday|Tuesday|Wednesday|Thursday|Friday|Saturday),\s+([A-Za-z]+\s+\d+,\s+\d{4})$/i;

  const lines = weekText.split('\n');
  let currentDay = null;
  let currentContent = [];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    const headerMatch = line.match(dayHeaderPattern);

    if (headerMatch) {
      // Save the previous day
      if (currentDay) {
        currentDay.content = currentContent.join('\n').trim();
        if (currentDay.content) {
          days.push(currentDay);
        }
      }

      // Start a new day
      const dayName = headerMatch[1];
      const date = headerMatch[2];
      currentDay = {
        dayName,
        date,
        fullDate: `${dayName}, ${date}`,
        content: ''
      };
      currentContent = [line]; // Include the header
    } else if (currentDay) {
      currentContent.push(line);
    }
  }

  // Save the last day
  if (currentDay) {
    currentDay.content = currentContent.join('\n').trim();
    if (currentDay.content) {
      days.push(currentDay);
    }
  }

  return days;
}

// Extract date from content
function extractDate(content) {
  const lines = content.split('\n');
  const dateRegex = /(?:monday|tuesday|wednesday|thursday|friday|saturday|sunday),\s+([a-z]{3,9})\s+(\d{1,2}),\s+(\d{4})/i;
  const monthMap = {
    jan: 0, feb: 1, mar: 2, apr: 3, may: 4, jun: 5,
    jul: 6, aug: 7, sep: 8, oct: 9, nov: 10, dec: 11
  };

  for (const line of lines.slice(0, Math.min(15, lines.length))) {
    const match = line.trim().match(dateRegex);
    if (match) {
      const [, monthName, day, year] = match;
      const normalizedMonthKey = monthName.toLowerCase().substring(0, 3);
      const month = monthMap[normalizedMonthKey];
      if (month !== undefined) {
        const parsedDate = new Date(parseInt(year), month, parseInt(day));
        const y = parsedDate.getFullYear();
        const m = String(parsedDate.getMonth() + 1).padStart(2, '0');
        const d = String(parsedDate.getDate()).padStart(2, '0');
        return `${y}-${m}-${d}`;
      }
    }
  }
  return null;
}

console.log('Testing Week Parser\n' + '='.repeat(50));

const days = parseWeekSchedule(sampleWeekData);

console.log(`\nFound ${days.length} days:\n`);

days.forEach((day, index) => {
  console.log(`Day ${index + 1}: ${day.fullDate}`);
  console.log(`  Content preview: ${day.content.substring(0, 100)}...`);

  const extractedDate = extractDate(day.content);
  console.log(`  Extracted date: ${extractedDate}`);

  if (extractedDate) {
    const dateObj = new Date(extractedDate + 'T12:00:00');
    console.log(`  Formatted: ${dateObj.toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}`);
  } else {
    console.log(`  ⚠️  WARNING: No date extracted!`);
  }
  console.log('');
});

console.log('='.repeat(50));
console.log('\nTest complete!');
