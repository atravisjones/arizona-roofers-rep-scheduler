import React from 'react';

const SchedulesHeader: React.FC = () => {
  return null;
};

export default SchedulesHeader;
